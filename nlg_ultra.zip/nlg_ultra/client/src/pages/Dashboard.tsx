import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Loader2, Copy, Trash2, Share2, MessageCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [selectedMessage, setSelectedMessage] = useState<any>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);

  // Fetch messages
  const { data: messages = [], isLoading: messagesLoading, refetch } = trpc.messages.list.useQuery();
  const deleteMutation = trpc.messages.delete.useMutation({
    onSuccess: () => {
      toast.success("Message deleted");
      refetch();
      setSelectedMessage(null);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to delete message");
    },
  });

  // Generate personal link
  const personalLink = user ? `${window.location.origin}/send?to=${user.id}` : "";

  // Copy link to clipboard
  const copyLink = () => {
    navigator.clipboard.writeText(personalLink);
    toast.success("Link copied to clipboard!");
  };

  // Generate AI suggestions when message is selected
  useEffect(() => {
    if (selectedMessage && !suggestions.length) {
      generateSuggestions();
    }
  }, [selectedMessage]);

  const generateSuggestions = async () => {
    setLoadingSuggestions(true);
    try {
      // Call the API directly
      const params = new URLSearchParams({
        input: JSON.stringify({ messageText: selectedMessage.text }),
      });
      const response = await fetch(`/api/trpc/ai.generateReplySuggestions?${params}`);
      const data = await response.json();
      if (data.result?.data?.suggestions) {
        setSuggestions(data.result.data.suggestions);
      }
    } catch (error) {
      console.error("Failed to generate suggestions:", error);
      toast.error("Failed to generate suggestions");
    } finally {
      setLoadingSuggestions(false);
    }
  };

  const copySuggestion = (suggestion: string) => {
    navigator.clipboard.writeText(suggestion);
    toast.success("Suggestion copied!");
  };

  const deleteMessage = (id: number) => {
    if (confirm("Delete this message?")) {
      deleteMutation.mutate({ id });
    }
  };

  const shareOnMessenger = () => {
    const url = `https://www.facebook.com/dialog/share?app_id=YOUR_APP_ID&href=${encodeURIComponent(personalLink)}&display=popup`;
    window.open(url, "_blank", "width=600,height=400");
  };

  const shareOnInstagram = () => {
    alert("📸 Share this link on your Instagram bio:\n\n" + personalLink);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4 text-cyan-400" />
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-white/10 bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img
              src={`https://ui-avatars.com/api/?name=${encodeURIComponent(user.name || "User")}&background=00d2ff&color=05070a`}
              alt={user.name || "User"}
              className="w-12 h-12 rounded-full border-2 border-cyan-400"
            />
            <div>
              <h1 className="text-xl font-bold text-gradient">NGLX ULTRA</h1>
              <p className="text-sm text-muted-foreground">{user.name || "User"}</p>
            </div>
          </div>
          <Button
            onClick={logout}
            variant="outline"
            className="border-red-500 text-red-400 hover:bg-red-500/10"
          >
            Logout
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="container py-8">
        {/* Personal Link Card */}
        <Card className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl mb-8 p-6 border-cyan-400/30">
          <h2 className="text-lg font-bold mb-4 text-gradient">Your Personal Link</h2>
          <div className="bg-black/40 rounded-lg p-4 mb-4 break-all font-mono text-sm">
            {personalLink}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <Button onClick={copyLink} className="btn-primary gap-2 col-span-1 sm:col-span-2">
              <Copy className="w-4 h-4" /> Copy Link
            </Button>
            <Button onClick={shareOnMessenger} className="btn-secondary gap-2">
              💬 Messenger
            </Button>
            <Button onClick={shareOnInstagram} className="btn-secondary gap-2">
              📸 Instagram
            </Button>
          </div>
        </Card>

        {/* Messages Section */}
        <div>
          <h2 className="text-2xl font-bold mb-6">
            Inbox{" "}
            <span className="badge-cyan">
              {messages.filter((m) => m.approved).length}
            </span>
          </h2>

          {messagesLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
            </div>
          ) : messages.filter((m) => m.approved).length === 0 ? (
            <Card className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-12 text-center border-dashed">
              <MessageCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
              <p className="text-muted-foreground">No messages yet. Share your link to get started!</p>
            </Card>
          ) : (
            <div className="space-y-4">
              {messages
                .filter((m) => m.approved)
                .map((message) => (
                  <Card
                    key={message.id}
                    className="message-card cursor-pointer hover:bg-white/10 transition-all"
                    onClick={() => {
                      setSelectedMessage(message);
                      setSuggestions([]);
                    }}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex gap-2 mb-2">
                          <span className="badge-cyan text-xs">
                            {message.device || "Unknown"}
                          </span>
                          <span className="badge-purple text-xs">
                            {new Date(message.createdAt).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-foreground line-clamp-2">{message.text}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteMessage(message.id);
                        }}
                        className="text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </Card>
                ))}
            </div>
          )}
        </div>
      </div>

      {/* Message Detail Dialog */}
      <Dialog open={!!selectedMessage} onOpenChange={() => setSelectedMessage(null)}>
        <DialogContent className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl border-cyan-400/30 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-gradient">Message Details</DialogTitle>
          </DialogHeader>

          {selectedMessage && (
            <div className="space-y-6">
              {/* Message Content */}
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground mb-2">Message</h3>
                <p className="text-foreground whitespace-pre-wrap">{selectedMessage.text}</p>
              </div>

              {/* Metadata */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground">Device</p>
                  <p className="font-semibold">{selectedMessage.device || "Unknown"}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Received</p>
                  <p className="font-semibold">
                    {new Date(selectedMessage.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>

              {/* AI Reply Suggestions */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-muted-foreground">
                    💡 AI Reply Suggestions
                  </h3>
                  {loadingSuggestions && (
                    <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />
                  )}
                </div>

                {suggestions.length > 0 ? (
                  <div className="space-y-2">
                    {suggestions.map((suggestion, idx) => (
                      <div
                        key={idx}
                        className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-3 flex items-start justify-between gap-3 hover:border-cyan-400/50 transition-all"
                      >
                        <p className="text-sm flex-1">{suggestion}</p>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => copySuggestion(suggestion)}
                          className="text-cyan-400 hover:bg-cyan-400/10 flex-shrink-0"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : loadingSuggestions ? (
                  <p className="text-sm text-muted-foreground">Generating suggestions...</p>
                ) : (
                  <p className="text-sm text-muted-foreground">No suggestions available</p>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-3">
                <Button
                  onClick={() => deleteMessage(selectedMessage.id)}
                  variant="destructive"
                  className="flex-1"
                >
                  <Trash2 className="w-4 h-4 mr-2" /> Delete
                </Button>
                <Button
                  onClick={() => setSelectedMessage(null)}
                  className="flex-1 btn-primary"
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
