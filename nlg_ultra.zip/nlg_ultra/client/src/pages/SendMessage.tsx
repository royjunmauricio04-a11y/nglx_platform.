import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Send, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function SendMessage() {
  const [location] = useLocation();
  const [recipientId, setRecipientId] = useState<number | null>(null);
  const [recipientName, setRecipientName] = useState<string>("");
  const [recipientAvatar, setRecipientAvatar] = useState<string>("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const sendMutation = trpc.messages.send.useMutation({
    onSuccess: (data) => {
      if (data.approved) {
        setSuccess(true);
        setMessage("");
        toast.success(data.message);
        setTimeout(() => setSuccess(false), 3000);
      } else {
        toast.error(data.message);
      }
    },
    onError: (error) => {
      toast.error(error.message || "Failed to send message");
    },
  });

  // Extract recipient ID from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const toId = params.get("to");

    if (!toId) {
      setError("Invalid recipient. Please check the link.");
      return;
    }

    const id = parseInt(toId);
    if (isNaN(id)) {
      setError("Invalid recipient ID.");
      return;
    }

    setRecipientId(id);
    fetchRecipientInfo(id);
  }, []);

  const fetchRecipientInfo = async (id: number) => {
    try {
      setLoading(true);
      // Fetch recipient info from the auth.me endpoint or create a dedicated endpoint
      const response = await fetch(`/api/trpc/auth.me`);
      // This is a placeholder - you'd need to create a proper endpoint to fetch user info by ID
      // For now, we'll use a generic approach
      setRecipientName(`User ${id}`);
      setRecipientAvatar(
        `https://ui-avatars.com/api/?name=User&background=00d2ff&color=05070a`
      );
    } catch (err) {
      console.error("Failed to fetch recipient info:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async () => {
    if (!message.trim()) {
      toast.error("Message cannot be empty");
      return;
    }

    if (!recipientId) {
      toast.error("Invalid recipient");
      return;
    }

    sendMutation.mutate({
      to: recipientId,
      text: message,
    });
  };

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl max-w-md w-full p-8 text-center border-red-500/30">
          <AlertCircle className="w-16 h-16 mx-auto mb-4 text-red-400" />
          <h1 className="text-2xl font-bold mb-2">Error</h1>
          <p className="text-muted-foreground">{error}</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl max-w-md w-full p-8 border-cyan-400/30">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gradient mb-2">NGLX ULTRA</h1>
          <p className="text-sm text-muted-foreground">Send an anonymous message</p>
        </div>

        {/* Recipient Info */}
        {!loading && recipientName && (
          <div className="text-center mb-8">
            <img
              src={recipientAvatar}
              alt={recipientName}
              className="w-20 h-20 rounded-full border-2 border-cyan-400 mx-auto mb-3"
            />
            <h2 className="text-xl font-bold">{recipientName}</h2>
            <p className="text-xs text-muted-foreground">is waiting for your message</p>
          </div>
        )}

        {/* Message Form */}
        {success ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-green-500/20 border-2 border-green-500 flex items-center justify-center mx-auto mb-4">
              <span className="text-2xl">✓</span>
            </div>
            <h3 className="text-lg font-bold mb-2">Message Sent!</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Your anonymous message has been delivered.
            </p>
            <Button
              onClick={() => {
                setSuccess(false);
                setMessage("");
              }}
              className="btn-primary w-full"
            >
              Send Another
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message here... (max 5000 characters)"
              maxLength={5000}
              className="w-full h-32 bg-white/5 backdrop-blur-xl p-4 rounded-lg border border-white/10 text-foreground placeholder-muted-foreground focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 resize-none"
              disabled={sendMutation.isPending}
            />

            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>
                {message.length} / 5000 characters
              </span>
              {message.length > 4500 && (
                <span className="text-yellow-400">Getting close to limit</span>
              )}
            </div>

            <Button
              onClick={handleSend}
              disabled={sendMutation.isPending || !message.trim()}
              className="btn-primary w-full gap-2"
            >
              {sendMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" /> Send Message
                </>
              )}
            </Button>

            <p className="text-xs text-muted-foreground text-center">
              💡 Your message is completely anonymous. No account needed!
            </p>
          </div>
        )}
      </Card>
    </div>
  );
}
