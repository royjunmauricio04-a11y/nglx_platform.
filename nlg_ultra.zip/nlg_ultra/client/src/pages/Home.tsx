import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { MessageCircle, Lock, Zap, Share2 } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useEffect } from "react";

export default function Home() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  // Redirect to dashboard if already authenticated
  useEffect(() => {
    if (user && !loading) {
      setLocation("/dashboard");
    }
  }, [user, loading]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Animated background elements */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-white/10 bg-card/50 backdrop-blur-sm sticky top-0 z-40">
          <div className="container py-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-8 h-8 text-cyan-400" />
              <h1 className="text-2xl font-bold text-gradient">NGLX ULTRA</h1>
            </div>
            {!loading && !user && (
              <a href={getLoginUrl()}>
                <Button className="btn-primary">Login</Button>
              </a>
            )}
          </div>
        </header>

        {/* Hero Section */}
        <section className="container py-20 md:py-32">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Receive{" "}
              <span className="text-gradient">Anonymous Messages</span>
              <br />
              Like Never Before
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Share your personal link and let anyone send you anonymous messages. No accounts needed for senders. AI-powered reply suggestions included.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={getLoginUrl()}>
                <Button className="btn-primary px-8 py-6 text-lg w-full sm:w-auto">
                  Get Started Free
                </Button>
              </a>
              <Button variant="outline" className="px-8 py-6 text-lg w-full sm:w-auto border-cyan-400 text-cyan-400 hover:bg-cyan-400/10">
                Learn More
              </Button>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-6 mt-20">
            {/* Feature 1 */}
            <Card className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 border-cyan-400/30 hover:border-cyan-400/60 transition-all">
              <div className="w-12 h-12 rounded-lg bg-cyan-400/20 flex items-center justify-center mb-4">
                <Lock className="w-6 h-6 text-cyan-400" />
              </div>
              <h3 className="text-xl font-bold mb-2">Completely Anonymous</h3>
              <p className="text-muted-foreground">
                Senders don't need an account. Their messages are 100% anonymous and can't be traced back.
              </p>
            </Card>

            {/* Feature 2 */}
            <Card className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 border-purple-500/30 hover:border-purple-500/60 transition-all">
              <div className="w-12 h-12 rounded-lg bg-purple-500/20 flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-purple-400" />
              </div>
              <h3 className="text-xl font-bold mb-2">AI Reply Suggestions</h3>
              <p className="text-muted-foreground">
                Get 3 witty or thoughtful reply suggestions for each message. Copy with one click.
              </p>
            </Card>

            {/* Feature 3 */}
            <Card className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 border-cyan-400/30 hover:border-cyan-400/60 transition-all">
              <div className="w-12 h-12 rounded-lg bg-cyan-400/20 flex items-center justify-center mb-4">
                <Share2 className="w-6 h-6 text-cyan-400" />
              </div>
              <h3 className="text-xl font-bold mb-2">Easy Sharing</h3>
              <p className="text-muted-foreground">
                Share your link on Instagram, Facebook Messenger, or copy to clipboard instantly.
              </p>
            </Card>
          </div>
        </section>

        {/* How It Works */}
        <section className="container py-20 border-t border-white/10">
          <h2 className="text-4xl font-bold text-center mb-16 text-gradient">How It Works</h2>

          <div className="max-w-4xl mx-auto space-y-8">
            {/* Step 1 */}
            <div className="flex gap-6 items-start">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 flex items-center justify-center flex-shrink-0 font-bold text-black">
                1
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Create Your Account</h3>
                <p className="text-muted-foreground">
                  Sign up with your email or Google account. It takes less than a minute.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-6 items-start">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 flex items-center justify-center flex-shrink-0 font-bold text-black">
                2
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Get Your Personal Link</h3>
                <p className="text-muted-foreground">
                  Instantly get a unique link. Share it anywhere - Instagram, TikTok, Discord, etc.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-6 items-start">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 flex items-center justify-center flex-shrink-0 font-bold text-black">
                3
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Receive Anonymous Messages</h3>
                <p className="text-muted-foreground">
                  Anyone can send you messages without an account. They're completely anonymous.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex gap-6 items-start">
              <div className="w-12 h-12 rounded-full bg-gradient-to-r from-cyan-400 to-purple-500 flex items-center justify-center flex-shrink-0 font-bold text-black">
                4
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Get AI Suggestions & Reply</h3>
                <p className="text-muted-foreground">
                  View messages in your dashboard and get AI-powered reply suggestions instantly.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="container py-20 border-t border-white/10">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-12 rounded-2xl border-cyan-400/30 text-center">
            <h2 className="text-4xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Join thousands of users receiving anonymous messages with AI-powered insights.
            </p>
            <a href={getLoginUrl()}>
              <Button className="btn-primary px-8 py-6 text-lg">
                Create Account Now
              </Button>
            </a>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-white/10 bg-card/30 backdrop-blur-sm py-8 mt-20">
          <div className="container text-center text-muted-foreground text-sm">
            <p>© 2026 NGLX ULTRA. All rights reserved. Built with ❤️ for anonymous conversations.</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
