import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, bigint } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// TODO: Add additional tables here as your schema grows

/**
 * Messages table for storing anonymous messages.
 * Messages are anonymous (no sender ID), only recipient (to) is stored.
 */
export const messages = mysqlTable("messages", {
  id: bigint("id", { mode: "number" }).autoincrement().primaryKey(),
  /** User ID of the recipient */
  to: int("to").notNull(),
  /** Message content */
  text: text("text").notNull(),
  /** Device type detected from user agent */
  device: varchar("device", { length: 50 }),
  /** Whether message passed content moderation */
  approved: boolean("approved").default(true).notNull(),
  /** Reason for rejection if not approved */
  rejectionReason: varchar("rejectionReason", { length: 255 }),
  /** Timestamp when message was created */
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// Relations
export const messagesRelations = relations(messages, ({ one }) => ({
  recipient: one(users, {
    fields: [messages.to],
    references: [users.id],
  }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  messages: many(messages),
}));