CREATE TABLE `messages` (
	`id` bigint AUTO_INCREMENT NOT NULL,
	`to` int NOT NULL,
	`text` text NOT NULL,
	`device` varchar(50),
	`approved` boolean NOT NULL DEFAULT true,
	`rejectionReason` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
