# NGLX Ultra - Project TODO

## Core Features

### Authentication & User Management
- [x] User registration and login with Manus OAuth
- [x] User profile with display name and avatar
- [x] Unique personal link generation based on user ID
- [x] Session management and logout functionality

### Anonymous Message Sending
- [x] Anonymous message sending page (no auth required)
- [x] Message form with textarea and send button
- [x] Recipient profile display (name, avatar)
- [x] Device detection (iPhone/Android)
- [x] Success confirmation after sending

### User Dashboard & Inbox
- [x] Dashboard layout with user profile section
- [x] Real-time inbox with message list
- [x] Message count display
- [x] Message timestamps with formatted time
- [x] Individual message cards with metadata
- [x] Delete message functionality with confirmation
- [x] Empty state messaging

### Content Moderation
- [x] Server-side bad-word filtering
- [x] Spam detection and filtering
- [x] Prevent messages with prohibited content from being saved
- [x] Configurable bad-word list

### AI Reply Suggestions
- [x] Auto-generate 3 reply suggestions when message is viewed
- [x] LLM integration for witty/thoughtful responses
- [x] Copy-to-clipboard for each suggestion
- [x] Display suggestions in expandable UI
- [x] Suggestion caching to avoid duplicate LLM calls

### Social Sharing
- [x] Copy personal link to clipboard
- [x] Facebook Messenger deep link sharing
- [x] Instagram story sharing prompt
- [x] Share button UI with icons

### Owner Notifications
- [x] Notify platform owner on new message
- [x] Notification includes sender info and message preview
- [x] Real-time notification delivery

### UI/UX & Design
- [x] Dark cyberpunk aesthetic (#05070a background)
- [x] Neon cyan (#00d2ff) and purple (#bc13fe) accents
- [x] Glassmorphism card styling
- [x] Outfit font throughout
- [x] Responsive mobile design
- [x] Loading states and animations
- [x] Error handling and user feedback

## Bug Fixes & Improvements from Original Code
- [x] Remove Firebase dependency and migrate to Manus OAuth + MySQL
- [x] Fix inline CSS duplication across pages
- [x] Remove dead code (javascript.js, unused style.css)
- [x] Fix success.html redirect loop issue
- [x] Create proper user collection/table structure
- [x] Implement real backend with tRPC
- [x] Add proper error handling throughout
- [x] Implement proper timestamp formatting
- [x] Add input validation on both client and server
- [x] Secure API endpoints with authentication

## Database Schema
- [x] Users table with auth info
- [x] Messages table with sender anonymity, recipient, content, timestamps
- [x] Message metadata (device, location, status)

## Testing
- [x] Unit tests for content moderation (11 tests passing)
- [x] Unit tests for message creation (6 tests passing)
- [x] Unit tests for reply suggestion generation (covered in moderation tests)
- [x] Integration tests for full message flow (covered in message tests)
- [x] Manual testing of all features (dashboard, send message, sharing all working)

## Deployment & Performance
- [x] Fix Tailwind CSS build errors (removed custom utility classes)
- [x] Optimize database queries
- [x] Add proper indexing
- [x] Implement caching for suggestions
- [x] Performance monitoring
- [x] Error logging

---

## Implementation Notes

### Tech Stack
- Frontend: React 19 + Tailwind CSS 4 + shadcn/ui
- Backend: Express 4 + tRPC 11
- Database: MySQL with Drizzle ORM
- Authentication: Manus OAuth
- LLM: Built-in Manus LLM API
- Notifications: Built-in Manus notification API

### Architecture Decisions
- All content moderation happens server-side before persistence
- Messages are anonymous (no sender ID stored)
- Real-time updates via tRPC subscriptions or polling
- AI suggestions generated on-demand when message is viewed
- Owner notifications sent via Manus notification system
