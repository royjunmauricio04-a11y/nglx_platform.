/**
 * Content moderation utilities for filtering spam and inappropriate content
 */

// Configurable list of prohibited words
const BAD_WORDS = [
  "spam",
  "scam",
  "phishing",
  "malware",
  "virus",
  "xxx",
  "porn",
  "adult",
];

// Spam detection patterns
const SPAM_PATTERNS = [
  /(?:http|https):\/\/[^\s]+/i, // URLs
  /\b(?:click here|buy now|limited offer|act now)\b/i, // Common spam phrases
  /(.)\1{5,}/i, // Repeated characters (e.g., "aaaaaa")
];

/**
 * Check if message contains prohibited words
 */
export function containsBadWords(text: string): boolean {
  const lowerText = text.toLowerCase();
  return BAD_WORDS.some((word) => lowerText.includes(word));
}

/**
 * Check if message appears to be spam
 */
export function isSpam(text: string): boolean {
  // Check for spam patterns
  for (const pattern of SPAM_PATTERNS) {
    pattern.lastIndex = 0; // Reset regex state
    if (pattern.test(text)) {
      return true;
    }
  }

  // Check for excessive capitalization (more than 50% caps)
  const capsCount = (text.match(/[A-Z]/g) || []).length;
  if (text.length > 10 && capsCount / text.length > 0.5) {
    return true;
  }

  return false;
}

/**
 * Validate message content and return moderation result
 */
export function moderateMessage(text: string): {
  approved: boolean;
  reason?: string;
} {
  // Check message length
  if (!text || text.trim().length === 0) {
    return {
      approved: false,
      reason: "Message is empty",
    };
  }

  if (text.length > 5000) {
    return {
      approved: false,
      reason: "Message is too long (max 5000 characters)",
    };
  }

  // Check for bad words
  if (containsBadWords(text)) {
    return {
      approved: false,
      reason: "Message contains prohibited content",
    };
  }

  // Check for spam
  if (isSpam(text)) {
    return {
      approved: false,
      reason: "Message appears to be spam",
    };
  }

  return {
    approved: true,
  };
}
