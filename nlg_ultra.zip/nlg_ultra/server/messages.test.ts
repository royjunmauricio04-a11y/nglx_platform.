import { describe, it, expect } from "vitest";
import { moderateMessage } from "./moderation";
import { z } from "zod";

describe("Message Creation & Validation", () => {
  const sendInputSchema = z.object({
    to: z.number().int().positive("Invalid recipient"),
    text: z.string().min(1, "Message cannot be empty").max(5000),
  });

  it("should validate recipient ID is positive", () => {
    expect(() => {
      sendInputSchema.parse({ to: 0, text: "Hello" });
    }).toThrow();

    expect(() => {
      sendInputSchema.parse({ to: -1, text: "Hello" });
    }).toThrow();
  });

  it("should validate message is not empty", () => {
    expect(() => {
      sendInputSchema.parse({ to: 1, text: "" });
    }).toThrow();
  });

  it("should validate message does not exceed 5000 characters", () => {
    expect(() => {
      sendInputSchema.parse({ to: 1, text: "a".repeat(5001) });
    }).toThrow();
  });

  it("should accept valid message input", () => {
    const valid = sendInputSchema.parse({
      to: 123,
      text: "Hello, this is a valid message!",
    });

    expect(valid.to).toBe(123);
    expect(valid.text).toBe("Hello, this is a valid message!");
  });

  it("should block messages with bad content before persistence", () => {
    const input = {
      to: 1,
      text: "Buy spam now at http://spam.com",
    };

    const validated = sendInputSchema.parse(input);
    const moderation = moderateMessage(validated.text);

    if (!moderation.approved) {
      expect(moderation.approved).toBe(false);
      expect(moderation.reason).toBeDefined();
      return;
    }

    throw new Error("Should reject spam message");
  });

  it("should allow clean messages to be created", () => {
    const input = {
      to: 1,
      text: "Hi, I wanted to say hello!",
    };

    const validated = sendInputSchema.parse(input);
    const moderation = moderateMessage(validated.text);

    expect(moderation.approved).toBe(true);
    expect(validated.to).toBe(1);
    expect(validated.text).toBe("Hi, I wanted to say hello!");
  });
});
