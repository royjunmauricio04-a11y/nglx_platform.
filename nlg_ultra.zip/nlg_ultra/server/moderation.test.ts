import { describe, expect, it } from "vitest";
import { containsBadWords, isSpam, moderateMessage } from "./moderation";

describe("Content Moderation", () => {
  describe("containsBadWords", () => {
    it("should detect bad words", () => {
      expect(containsBadWords("This is spam content")).toBe(true);
      expect(containsBadWords("Check out this scam")).toBe(true);
      expect(containsBadWords("Hello world")).toBe(false);
    });

    it("should be case-insensitive", () => {
      expect(containsBadWords("SPAM")).toBe(true);
      expect(containsBadWords("SpAm")).toBe(true);
    });
  });

  describe("isSpam", () => {
    it("should detect URLs", () => {
      expect(isSpam("Check this out: http://example.com")).toBe(true);
      expect(isSpam("Visit https://malicious.site now")).toBe(true);
    });

    it("should detect common spam phrases", () => {
      expect(isSpam("Click here now!")).toBe(true);
      expect(isSpam("Limited offer - buy now!")).toBe(true);
    });

    it("should detect repeated characters", () => {
      expect(isSpam("Hellooooooo world")).toBe(true);
      expect(isSpam("AAAAAAAAA")).toBe(true);
    });

    it("should detect excessive capitalization", () => {
      expect(isSpam("THIS IS ALL CAPS TEXT")).toBe(true);
      expect(isSpam("This is normal text")).toBe(false);
    });
  });

  describe("moderateMessage", () => {
    it("should reject empty messages", () => {
      const result = moderateMessage("");
      expect(result.approved).toBe(false);
      expect(result.reason).toContain("empty");
    });

    it("should reject messages that are too long", () => {
      const longText = "a".repeat(5001);
      const result = moderateMessage(longText);
      expect(result.approved).toBe(false);
      expect(result.reason).toContain("too long");
    });

    it("should reject messages with bad words", () => {
      const result = moderateMessage("This is spam");
      expect(result.approved).toBe(false);
      expect(result.reason).toContain("prohibited");
    });

    it("should reject messages that are spam", () => {
      const result = moderateMessage("Check out http://example.com");
      expect(result.approved).toBe(false);
      expect(result.reason).toContain("spam");
    });

    it("should approve clean messages", () => {
      const result = moderateMessage("Hello, how are you doing today?");
      expect(result.approved).toBe(true);
      expect(result.reason).toBeUndefined();
    });
  });
});
