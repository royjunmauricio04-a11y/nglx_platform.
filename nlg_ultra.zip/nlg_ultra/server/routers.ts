import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getUserMessages, createMessage, deleteMessage } from "./db";
import { moderateMessage } from "./moderation";
import { notifyOwner } from "./_core/notification";
import { aiRouter } from "./routers/ai";
import { usersRouter } from "./routers/users";

export const appRouter = router({
  system: systemRouter,
  ai: aiRouter,
  users: usersRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  messages: router({
    /**
     * Get all messages for the authenticated user
     */
    list: protectedProcedure.query(async ({ ctx }) => {
      return await getUserMessages(ctx.user.id);
    }),

    /**
     * Send an anonymous message to a user
     * Public endpoint - no authentication required
     * Messages are rejected server-side before being saved if they fail moderation
     */
    send: publicProcedure
      .input(
        z.object({
          to: z.number().int().positive("Invalid recipient"),
          text: z.string().min(1, "Message cannot be empty").max(5000),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Moderate the message content FIRST
        const moderation = moderateMessage(input.text);

        // If moderation fails, reject immediately without saving to database
        if (!moderation.approved) {
          return {
            success: false,
            approved: false,
            message: `Message rejected: ${moderation.reason}`,
          };
        }

        // Detect device from user agent
        const userAgent = (ctx.req.headers["user-agent"] as string) || "";
        const device = /iPhone|iPad|iPod/i.test(userAgent) ? "iPhone" : "Android";

        // Create message in database ONLY if it passed moderation
        const message = await createMessage({
          to: input.to,
          text: input.text,
          device,
          approved: true,
          rejectionReason: undefined,
        });

        // Notify owner of approved message
        try {
          await notifyOwner({
            title: "New Anonymous Message",
            content: `You received a new message: "${input.text.substring(0, 100)}${input.text.length > 100 ? "..." : ""}"`,
          });
        } catch (error) {
          console.error("Failed to notify owner:", error);
          // Don't fail the request if notification fails
        }

        return {
          success: true,
          messageId: message.id,
          approved: true,
          message: "Message sent successfully!",
        };
      }),

    /**
     * Delete a message (only owner can delete)
     */
    delete: protectedProcedure
      .input(z.object({ id: z.number().int().positive() }))
      .mutation(async ({ input, ctx }) => {
        // Verify the message belongs to the user
        const messages = await getUserMessages(ctx.user.id);
        const messageExists = messages.some((m) => m.id === input.id);

        if (!messageExists) {
          throw new Error("Message not found or unauthorized");
        }

        await deleteMessage(input.id);

        return {
          success: true,
          message: "Message deleted successfully",
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
