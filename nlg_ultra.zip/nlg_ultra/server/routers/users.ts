import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { getUserByOpenId, getDb } from "../db";
import { users } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

export const usersRouter = router({
  /**
   * Get public profile information for a user by ID
   * Used for displaying recipient info on the send message page
   */
  getProfile: publicProcedure
    .input(z.object({ id: z.number().int().positive() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new Error("Database not available");
        }

        const user = await db
          .select({
            id: users.id,
            name: users.name,
            email: users.email,
          })
          .from(users)
          .where(eq(users.id, input.id))
          .limit(1);

        if (!user || user.length === 0) {
          return {
            found: false,
            user: null,
          };
        }

        return {
          found: true,
          user: {
            id: user[0].id,
            name: user[0].name || "User",
            email: user[0].email,
          },
        };
      } catch (error) {
        console.error("Failed to fetch user profile:", error);
        return {
          found: false,
          user: null,
        };
      }
    }),
});
