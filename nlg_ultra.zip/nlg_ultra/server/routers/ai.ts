import { publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import { invokeLLM } from "../_core/llm";

export const aiRouter = router({
  /**
   * Generate AI reply suggestions for a message
   */
  generateReplySuggestions: publicProcedure
    .input(
      z.object({
        messageText: z.string().min(1),
      })
    )
    .query(async ({ input }) => {
      try {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: "You are a helpful assistant that generates witty, thoughtful, and creative reply suggestions for anonymous messages.",
            },
            {
              role: "user",
              content: `Generate exactly 3 witty, thoughtful reply suggestions for this message. Return ONLY valid JSON: {"suggestions": ["s1", "s2", "s3"]}\n\nMessage: "${input.messageText}"`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "reply_suggestions",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  suggestions: {
                    type: "array",
                    items: {
                      type: "string",
                    },
                    minItems: 3,
                    maxItems: 3,
                  },
                },
                required: ["suggestions"],
                additionalProperties: false,
              },
            },
          },
        });

        // Parse the response
        const content = response.choices[0]?.message?.content;
        if (!content || typeof content !== "string") {
          throw new Error("No response from LLM");
        }

        const parsed = JSON.parse(content);
        return {
          suggestions: parsed.suggestions || [],
        };
      } catch (error) {
        console.error("Failed to generate suggestions:", error);
        // Return fallback suggestions if LLM fails
        return {
          suggestions: [
            "Thanks for reaching out! 💙",
            "This made my day! 🌟",
            "I appreciate you taking the time to send this!",
          ],
        };
      }
    }),
});
